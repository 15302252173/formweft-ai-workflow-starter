/* Original local compositor. No uploads, microphone, external codecs or runtime. */
(function (root) {
  'use strict';
  const MAX_SECONDS = 600, MAX_BYTES = 268435456;
  let lastDiagnostics = null;
  const TYPES = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1.42E01E,mp4a.40.2', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm;codecs=vp8,opus', 'video/webm'];
  const formats = Recorder => typeof Recorder?.isTypeSupported === 'function' ? TYPES.filter(type => Recorder.isTypeSupported(type)) : [];
  const formatFor = Recorder => formats(Recorder)[0] || '';
  // Real MediaRecorder output is VFR. Accept at most 5% fewer frames, with a
  // two-frame endpoint allowance for short clips; never accept 1 Hz captures.
  const minimumFrameCount = expected => Math.max(1, expected - Math.max(2, Math.floor(expected * .05)));
  function validateRange(start, end, fps, duration, mediaDuration) {
    if (![start, end, duration, mediaDuration].every(Number.isFinite) || start < 0 || end <= start || end > duration || end > mediaDuration + .001) throw new Error('成品范围必须在项目和原视频时长以内，且出点晚于入点。');
    if (end - start > MAX_SECONDS) throw new Error('成品一次最多 10 分钟，请分段导出。');
    if (![12, 24, 30].includes(fps)) throw new Error('成品帧率必须为 12、24 或 30。');
    return { start, end: Math.min(end, mediaDuration), fps };
  }
  function containRect(sourceWidth, sourceHeight, width, height) {
    if (![sourceWidth, sourceHeight, width, height].every(value => Number.isFinite(value) && value > 0)) throw new Error('视频画面尺寸无效。');
    const scale = Math.min(width / sourceWidth, height / sourceHeight);
    return { x: (width - sourceWidth * scale) / 2, y: (height - sourceHeight * scale) / 2, width: sourceWidth * scale, height: sourceHeight * scale };
  }
  // Read metadata boxes only, never copy a potentially 256 MiB mdat into JS.
  // Native Chrome MP4 is fragmented: stsz is empty; samples live in trun.
  async function countMp4VideoFrames(blob, signal) {
    const invalid = () => { throw new Error('无法核验 MP4 视频帧数：容器结构无效或超出安全范围，未下载文件。'); };
    if (!blob || typeof blob.slice !== 'function' || !Number.isSafeInteger(blob.size) || blob.size < 8 || blob.size > MAX_BYTES) invalid();
    let boxes = 0, metadataBytes = 0, position = 0;
    const videos = new Map(), fragments = new Map();
    const u32 = (data, at, end = data.length) => { if (at < 0 || at + 4 > Math.min(end, data.length)) invalid(); return new DataView(data.buffer, data.byteOffset, data.byteLength).getUint32(at); };
    const word = (data, at, end = data.length) => { u32(data, at, end); return String.fromCharCode(...data.subarray(at, at + 4)); };
    const header = (data, at, end) => {
      if (++boxes > 10000 || end - at < 8) invalid();
      let size = u32(data, at), bytes = 8;
      if (size === 1) { size = u32(data, at + 8) * 4294967296 + u32(data, at + 12); bytes = 16; }
      else if (size === 0) size = end - at;
      if (!Number.isSafeInteger(size) || size < bytes || size > end - at) invalid();
      return { type: word(data, at + 4), payload: at + bytes, end: at + size, size };
    };
    const children = (data, box) => {
      const result = []; let at = box.payload;
      while (at < box.end) { const child = header(data, at, box.end); result.push(child); at = child.end; }
      return result;
    };
    const one = (list, type, required = true) => { const found = list.filter(box => box.type === type); if (found.length > 1 || (required && !found.length)) invalid(); return found[0]; };
    while (position < blob.size) {
      if (signal?.aborted) throw signal.reason;
      const prefix = new Uint8Array(await blob.slice(position, Math.min(blob.size, position + 16)).arrayBuffer());
      const top = header(prefix, 0, blob.size - position);
      if (top.type === 'moov' || top.type === 'moof') {
        metadataBytes += top.size;
        if (top.size > 2097152 || metadataBytes > 8388608) invalid();
        const data = new Uint8Array(await blob.slice(position, position + top.size).arrayBuffer()), rootChildren = children(data, top);
        if (top.type === 'moov') {
          for (const track of rootChildren.filter(box => box.type === 'trak')) {
            const trackChildren = children(data, track), tkhd = one(trackChildren, 'tkhd'), mdia = one(trackChildren, 'mdia');
            u32(data, tkhd.payload, tkhd.end); const version = data[tkhd.payload]; if (version > 1) invalid();
            const id = u32(data, tkhd.payload + (version === 1 ? 20 : 12), tkhd.end); if (!id) invalid();
            const mediaChildren = children(data, mdia), handler = one(mediaChildren, 'hdlr');
            if (word(data, handler.payload + 8, handler.end) !== 'vide') continue;
            if (videos.has(id)) invalid();
            const minf = one(mediaChildren, 'minf'), stbl = one(children(data, minf), 'stbl'), stsz = one(children(data, stbl), 'stsz');
            const sampleSize = u32(data, stsz.payload + 4, stsz.end), count = u32(data, stsz.payload + 8, stsz.end);
            if (count > 1000000 || (!sampleSize && count * 4 > stsz.end - stsz.payload - 12)) invalid();
            videos.set(id, count);
          }
        } else {
          for (const traf of rootChildren.filter(box => box.type === 'traf')) {
            const entries = children(data, traf), tfhd = one(entries, 'tfhd'), tf = u32(data, tfhd.payload, tfhd.end), id = u32(data, tfhd.payload + 4, tfhd.end);
            if (!id || (tf & ~0x03003b)) invalid();
            const optional = (tf & 1 ? 8 : 0) + [2, 8, 16, 32].filter(flag => tf & flag).length * 4;
            if (tfhd.payload + 8 + optional > tfhd.end) invalid();
            for (const trun of entries.filter(box => box.type === 'trun')) {
              const vf = u32(data, trun.payload, trun.end), flags = vf & 0xffffff, count = u32(data, trun.payload + 4, trun.end);
              if ((vf >>> 24) > 1 || (flags & ~0x000f05) || count > 1000000) invalid();
              const bytes = 8 + (flags & 1 ? 4 : 0) + (flags & 4 ? 4 : 0) + count * [256, 512, 1024, 2048].filter(flag => flags & flag).length * 4;
              if (trun.payload + bytes > trun.end) invalid();
              const total = (fragments.get(id) || 0) + count; if (total > 1000000) invalid(); fragments.set(id, total);
            }
          }
        }
      }
      position += top.size;
    }
    if (videos.size !== 1) invalid();
    const [id, flatCount] = [...videos][0], count = flatCount + (fragments.get(id) || 0);
    if (!Number.isSafeInteger(count) || count < 1 || count > 1000000) invalid();
    return count;
  }
  async function exportVideo({ project, mediaUrl, start, end, fps = 24, includeAudio = true, signal, previewHost, onProgress = () => {} }) {
    const C = root.MotionWorkbench, document = root.document, Recorder = root.MediaRecorder;
    if (!C || !document || !formatFor(Recorder)) throw new Error('此浏览器不支持本地成品录制。请使用新版 Chrome / Edge，或导出 PNG 序列。');
    if (typeof mediaUrl !== 'string' || !mediaUrl.startsWith('blob:')) throw new Error('请先选择本机视频，再导出成品。');
    if (typeof includeAudio !== 'boolean') throw new Error('原声选项无效。');
    const snapshot = C.validateProject(project);
    const diagnostics = { renders: 0, frameCallbacks: 0, requestedFrames: 0, capturedFrames: null, encodedFrames: null, maxDrawMs: 0, maxFrameGapMs: 0, sourceDecodedFrames: 0, elapsedMs: 0, completed: false };
    lastDiagnostics = diagnostics; const began = performance.now();
    if (document.hidden) throw new Error('请保持工作台在前台再导出成品。');
    const controller = new AbortController(), removers = [], chunks = [];
    const video = document.createElement('video'), output = document.createElement('canvas'), overlay = document.createElement('canvas');
    let stream, audio, source, destination, recorder, captureTrack, frameReader, monitorTrack, frameLoop, frameTimer = 0, bytes = 0;
    const listen = (target, name, callback) => { target.addEventListener(name, callback); removers.push(() => target.removeEventListener(name, callback)); };
    const abort = message => { if (!controller.signal.aborted) controller.abort(new Error(message)); };
    const check = () => { if (controller.signal.aborted) throw controller.signal.reason; };
    const awaitAudio = promise => new Promise((resolve, reject) => {
      const cleanup = () => { clearTimeout(timer); controller.signal.removeEventListener('abort', cancelled); };
      const cancelled = () => { cleanup(); reject(controller.signal.reason); };
      const timer = setTimeout(() => { cleanup(); reject(new Error('浏览器未启用原声录制，请重新点击导出。')); }, 20000);
      controller.signal.addEventListener('abort', cancelled);
      if (controller.signal.aborted) { cancelled(); return; }
      promise.then(value => { cleanup(); resolve(value); }, error => { cleanup(); reject(error); });
    });
    const waitFor = (target, name, ready, timeout = 20000, begin) => new Promise((resolve, reject) => {
      if (controller.signal.aborted) { reject(controller.signal.reason); return; }
      if (target.error) { reject(new Error('本地视频解码失败，未生成可用成品。')); return; }
      if (!begin && ready()) { resolve(); return; }
      const cleanup = () => { clearTimeout(timer); target.removeEventListener(name, success); target.removeEventListener('error', failed); controller.signal.removeEventListener('abort', cancelled); };
      const success = () => { if (ready()) { cleanup(); resolve(); } };
      const failed = () => { cleanup(); reject(new Error('原视频无法读取或解码，请换一个浏览器支持的 MP4 / WebM 文件。')); };
      const cancelled = () => { cleanup(); reject(controller.signal.reason); };
      const timer = setTimeout(() => { cleanup(); reject(new Error('等待本地视频超时，请确认视频可正常播放后重试。')); }, timeout);
      target.addEventListener(name, success); target.addEventListener('error', failed); controller.signal.addEventListener('abort', cancelled);
      if (begin) { try { begin(); } catch (error) { cleanup(); reject(error); } }
    });
    const verifyWebM = async (blob, width, height) => {
      const probe = document.createElement('video'), pixels = document.createElement('canvas'); let url;
      try {
        if (typeof root.URL?.createObjectURL !== 'function') throw new Error('浏览器无法检查本地 WebM 成品。');
        url = root.URL.createObjectURL(blob); probe.muted = true; probe.playsInline = true; probe.preload = 'auto'; probe.src = url; probe.load();
        await waitFor(probe, 'loadedmetadata', () => probe.readyState >= 1);
        await waitFor(probe, 'loadeddata', () => probe.readyState >= 2);
        if (probe.videoWidth !== width || probe.videoHeight !== height) throw new Error('WebM 成品没有预期的视频画面。');
        pixels.width = pixels.height = 1; const context = pixels.getContext('2d', { willReadFrequently: true });
        const verifyFrame = () => {
          if (!context) throw new Error('浏览器无法检查 WebM 画面。');
          context.clearRect(0, 0, 1, 1); context.drawImage(probe, 0, 0, 1, 1);
          if (context.getImageData(0, 0, 1, 1).data[3] !== 255) throw new Error('WebM 成品没有可解码的视频画面。');
        };
        verifyFrame();
        const duration = end - start, allowance = Math.max(2 / fps, duration * .05), target = Math.max(0, duration - 1 / fps);
        const validDuration = () => probe.duration === Infinity || (Number.isFinite(probe.duration) && probe.duration > 0 && probe.duration >= duration - allowance);
        if (!validDuration()) throw new Error('WebM 成品时长不足或无效。');
        // Native MediaRecorder WebM can omit duration (Infinity). Decode a
        // frame near the end instead of rejecting valid streaming metadata.
        if (target > 0) {
          await waitFor(probe, 'seeked', () => !probe.seeking, 20000, () => { probe.currentTime = target; });
          await waitFor(probe, 'loadeddata', () => probe.readyState >= 2);
          if (!Number.isFinite(probe.currentTime) || Math.abs(probe.currentTime - target) > allowance || !validDuration()) throw new Error('WebM 成品未覆盖导出范围。');
          verifyFrame();
        }
        check();
      } finally {
        probe.pause(); probe.removeAttribute('src'); probe.load(); probe.remove();
        pixels.width = pixels.height = 0;
        if (url) root.URL.revokeObjectURL(url);
      }
    };
    listen(document, 'visibilitychange', () => { if (document.hidden) abort('导出已停止：工作台进入后台。请保持此页面可见并重新导出。'); });
    listen(root, 'pagehide', () => abort('页面已离开，成品导出已停止。'));
    if (signal) { listen(signal, 'abort', () => abort('已取消成品导出，未下载部分视频。')); if (signal.aborted) abort('已取消成品导出。'); }
    try {
      check();
      video.playsInline = true; video.preload = 'auto'; video.controls = false; video.loop = false; video.playbackRate = 1;
      for (const name of ['playsinline', 'webkit-playsinline', 'disablepictureinpicture', 'disableremoteplayback']) video.setAttribute(name, '');
      video.setAttribute('controlslist', 'nodownload nofullscreen noremoteplayback');
      // Keep the recording surfaces laid out and visible. Detached/occluded
      // media and rAF can be throttled even while document.hidden is false.
      const mount = previewHost || document.body;
      if (!mount?.append) throw new Error('没有可用的成品预览区域，请刷新页面后重试。');
      for (const surface of [video, output]) {
        surface.setAttribute('aria-hidden', 'true'); surface.className = 'video-export-surface';
        Object.assign(surface.style, previewHost ? { position: 'absolute', inset: '0', width: '100%', height: '100%', objectFit: 'contain', pointerEvents: 'none', zIndex: surface === output ? '4' : '3' }
          : { position: 'fixed', right: '16px', bottom: '16px', width: '320px', maxWidth: '80vw', pointerEvents: 'none', zIndex: surface === output ? '10001' : '10000' });
        mount.append(surface);
      }
      // This *separate* media element feeds only the recording destination, not
      // speakers. The preview is never connected to Web Audio or modified.
      let audioReady = Promise.resolve();
      if (includeAudio) {
        const Audio = root.AudioContext || root.webkitAudioContext;
        if (!Audio) throw new Error('此浏览器无法保留原声。请换用新版 Chrome / Edge，或明确关闭原声。');
        audio = new Audio(); source = audio.createMediaElementSource(video); destination = audio.createMediaStreamDestination(); source.connect(destination);
        audioReady = audio.resume(); audioReady.catch(() => {});
      } else video.muted = true;
      video.src = mediaUrl; video.load();
      onProgress({ phase: 'preparing', progress: 0, message: '正在准备本地视频和原声音轨…' });
      await waitFor(video, 'loadedmetadata', () => video.readyState >= 1);
      ({ start, end, fps } = validateRange(start, end, fps, snapshot.duration, video.duration));
      await waitFor(video, 'loadeddata', () => video.readyState >= 2);
      if (Math.abs(video.currentTime - start) > .001) { video.currentTime = start; await waitFor(video, 'seeked', () => !video.seeking && Math.abs(video.currentTime - start) < .05); }
      await awaitAudio(audioReady); check();
      if (audio && audio.state !== 'running') throw new Error('浏览器未启用原声录制。请在页面中重新点击导出。');
      const [width, height] = C.dimensions(snapshot.aspect);
      output.width = overlay.width = width; output.height = overlay.height = height;
      const context = output.getContext('2d', { alpha: false }), overlayContext = overlay.getContext('2d');
      if (!context || !overlayContext || typeof output.captureStream !== 'function') throw new Error('此浏览器不支持画布成品录制，请使用新版 Chrome / Edge。');
      const rect = containRect(video.videoWidth, video.videoHeight, width, height);
      const draw = at => {
        const drawStarted = performance.now();
        context.fillStyle = '#000'; context.fillRect(0, 0, width, height);
        context.drawImage(video, rect.x, rect.y, rect.width, rect.height);
        C.render(overlayContext, snapshot, at); context.drawImage(overlay, 0, 0);
        diagnostics.renders++; diagnostics.maxDrawMs = Math.max(diagnostics.maxDrawMs, performance.now() - drawStarted);
      };
      draw(start); stream = output.captureStream(fps);
      if (!stream.getVideoTracks().length) throw new Error('浏览器未创建视频画面轨道。');
      captureTrack = stream.getVideoTracks()[0];
      const requestFrame = () => { if (captureTrack.requestFrame) { captureTrack.requestFrame(); diagnostics.requestedFrames++; } };
      if (root.MediaStreamTrackProcessor && captureTrack.clone) {
        try {
          monitorTrack = captureTrack.clone(); frameReader = new root.MediaStreamTrackProcessor({ track: monitorTrack }).readable.getReader(); diagnostics.capturedFrames = 0;
          frameLoop = (async () => { while (true) { const item = await frameReader.read(); if (item.done) break; diagnostics.capturedFrames++; item.value.close(); } })().catch(() => { diagnostics.capturedFrames = null; });
        } catch (_) { monitorTrack?.stop(); monitorTrack = null; frameReader = null; }
      }
      if (destination) {
        const tracks = destination.stream.getAudioTracks();
        if (!tracks.length || tracks.some(track => track.readyState === 'ended')) throw new Error('浏览器未创建原声音轨，已停止导出。');
        tracks.forEach(track => stream.addTrack(track));
      }
      let chosen = '';
      for (const mimeType of formats(Recorder)) {
        try { recorder = new Recorder(stream, { mimeType, videoBitsPerSecond: 8000000, audioBitsPerSecond: 192000 }); chosen = mimeType; break; } catch (_) { /* A codec probe can still fail at construction. Try the next advertised format. */ }
      }
      if (!recorder) throw new Error('浏览器无法启动编码器，请关闭占用媒体的程序后重试。');
      const actualMime = recorder.mimeType || chosen, extension = actualMime.startsWith('video/mp4') ? 'mp4' : actualMime.startsWith('video/webm') ? 'webm' : '';
      if (!extension) throw new Error('浏览器返回了未知的视频格式，已停止导出。');
      await new Promise((resolve, reject) => {
        let finishing = false, failure = null, timer = 0, lastPaint = performance.now(), nextPaint = lastPaint, lastAdvance = lastPaint, previousTime = start;
        const finish = error => {
          if (finishing) { if (error && !failure) failure = error; return; }
          const expected = Math.ceil((end - start) * fps - 1e-8), minimum = minimumFrameCount(expected);
          if (!error && diagnostics.renders < minimum) error = new Error('实际渲染帧数不足（' + diagnostics.renders + ' / ' + expected + '），未下载低帧率成品。请保持窗口可见并重试。');
          finishing = true; failure = error || null; clearTimeout(frameTimer); frameTimer = 0; video.pause();
          timer = setTimeout(() => reject(failure || new Error('视频封装超时，未下载不完整文件。')), 10000);
          if (recorder.state !== 'inactive') { try { recorder.stop(); } catch (error) { clearTimeout(timer); reject(error); } }
          else { clearTimeout(timer); reject(failure || new Error('视频编码器提前停止。')); }
        };
        const interrupted = () => finish(controller.signal.reason);
        controller.signal.addEventListener('abort', interrupted);
        const watchdog = setInterval(() => { if (!finishing && performance.now() - lastAdvance > 3000) finish(new Error('原视频播放停滞或设备过忙，已停止导出。请缩短范围后重试。')); }, 500);
        const tidy = () => { clearInterval(watchdog); clearTimeout(timer); controller.signal.removeEventListener('abort', interrupted); };
        recorder.ondataavailable = event => {
          if (!event.data?.size || failure) return;
          bytes += event.data.size;
          if (bytes > MAX_BYTES) { finish(new Error('成品超过 256 MiB，请缩短范围后重试。')); return; }
          chunks.push(event.data);
        };
        recorder.onerror = event => finish(new Error('视频编码失败：' + (event.error?.message || '浏览器资源不足，请缩短范围后重试。')));
        recorder.onstop = () => { tidy(); if (!finishing) reject(new Error('编码器提前结束，未下载不完整视频。')); else if (failure) reject(failure); else if (!bytes) reject(new Error('编码器没有生成视频数据。')); else resolve(); };
        listen(video, 'error', () => finish(new Error('录制时原视频解码失败，未下载不完整视频。')));
        listen(video, 'ended', () => finish(video.currentTime >= end - .1 ? null : new Error('原视频提前结束，导出已停止。')));
        if (audio) listen(audio, 'statechange', () => { if (!finishing && audio.state !== 'running') finish(new Error('原声音轨被浏览器中断，导出已停止。')); });
        const tick = () => {
          if (finishing) return;
          try {
            const now = performance.now();
            check();
            diagnostics.frameCallbacks++; diagnostics.maxFrameGapMs = Math.max(diagnostics.maxFrameGapMs, now - lastPaint);
            if (now - lastPaint > 250) throw new Error('浏览器渲染被限速或中断，未下载低帧率成品。请保持窗口可见后重试。');
            lastPaint = now;
            const at = video.currentTime;
            if (at > previousTime + .001) { previousTime = at; lastAdvance = now; }
            if (at >= end) { finish(); return; }
            draw(at); requestFrame();
            onProgress({ phase: 'recording', progress: Math.min(99, (at - start) / (end - start) * 100), message: '正在合成 ' + extension.toUpperCase() + '：' + Math.max(0, at - start).toFixed(1) + ' / ' + (end - start).toFixed(1) + ' 秒 · 请保持此页面可见' });
            // Timers keep a regular capture cadence when window occlusion
            // reduces rAF to 1 Hz; hidden documents still explicitly abort.
            nextPaint = Math.max(nextPaint + 1000 / fps, now + 1);
            frameTimer = setTimeout(tick, Math.max(0, nextPaint - performance.now()));
          } catch (error) { finish(error); }
        };
        try { recorder.start(500); requestFrame(); video.play().catch(error => finish(new Error('浏览器未允许播放原视频：' + error.message))); frameTimer = setTimeout(tick, 0); }
        catch (error) { tidy(); finish(error); }
        removers.push(() => { tidy(); recorder.ondataavailable = recorder.onerror = recorder.onstop = null; });
      });
      check();
      const blob = new Blob(chunks, { type: actualMime });
      const head = new Uint8Array(await blob.slice(0, 12).arrayBuffer()); check();
      const correct = extension === 'mp4' ? String.fromCharCode(...head.slice(4, 8)) === 'ftyp' : head[0] === 0x1a && head[1] === 0x45 && head[2] === 0xdf && head[3] === 0xa3;
      if (!correct) throw new Error('编码器输出格式与声明不一致，未下载文件。请换用其他浏览器。');
      const expected = Math.ceil((end - start) * fps - 1e-8), minimum = minimumFrameCount(expected);
      if (extension === 'mp4') diagnostics.encodedFrames = await countMp4VideoFrames(blob, controller.signal);
      else {
        onProgress({ phase: 'validating', progress: 99, message: '正在检查 WebM 成品的首尾画面和时长…' });
        await verifyWebM(blob, width, height);
      }
      check();
      // The optional processor has its own lossy queue; only the encoded MP4
      // sample count is authoritative. WebM receives bounded decoder checks.
      if (diagnostics.encodedFrames !== null && diagnostics.encodedFrames < minimum) throw new Error('成品实际视频帧数不足，未下载低帧率文件。请保持窗口可见后重新导出。');
      onProgress({ phase: 'complete', progress: 100, message: '成品已封装完成。' });
      diagnostics.completed = true;
      return { blob, extension, mimeType: actualMime, duration: end - start, fps, width, height, audio: includeAudio };
    } finally {
      diagnostics.elapsedMs = performance.now() - began; diagnostics.sourceDecodedFrames = video.getVideoPlaybackQuality?.().totalVideoFrames || 0;
      removers.forEach(remove => remove()); clearTimeout(frameTimer);
      if (recorder && recorder.state !== 'inactive') { try { recorder.stop(); } catch (_) {} }
      video.pause(); video.removeAttribute('src'); video.load();
      video.remove(); output.remove();
      if (frameReader) await frameReader.cancel().catch(() => {}); monitorTrack?.stop(); if (frameLoop) await frameLoop;
      stream?.getTracks().forEach(track => track.stop()); destination?.stream.getTracks().forEach(track => track.stop());
      source?.disconnect(); destination?.disconnect(); if (audio && audio.state !== 'closed') await audio.close().catch(() => {});
      output.width = overlay.width = output.height = overlay.height = 0; chunks.length = 0;
    }
  }
  root.MotionWorkbenchExporter = Object.freeze({ MAX_SECONDS, MAX_BYTES, formatFor, minimumFrameCount, validateRange, containRect, countMp4VideoFrames, exportVideo, get lastDiagnostics() { return lastDiagnostics ? { ...lastDiagnostics } : null; } });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MotionWorkbenchExporter;
})(typeof globalThis !== 'undefined' ? globalThis : window);
