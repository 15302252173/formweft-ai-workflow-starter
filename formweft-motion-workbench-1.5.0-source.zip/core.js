/* FORMWEFT Motion Workbench. Original implementation; no third-party runtime. */
(function (root) {
  'use strict';
  const LIMITS = Object.freeze({ cards: 200, duration: 3600, text: 800, jsonBytes: 1048576, frames: 240, zipBytes: 268435456 });
  const TYPES = Object.freeze({ title: '开场标题', subtitle: '口播字幕', keypoint: '重点提示', metric: '数据强调', quote: '引用观点', steps: '步骤清单' });
  const ANIMATIONS = Object.freeze({ rise: '向上浮入', fade: '淡入淡出', pop: '轻缩放' });
  const hexColor = value => typeof value === 'string' && /^#[0-9a-fA-F]{6}$/.test(value);
  const cardStyle = card => ({ backgroundColor: card.type === 'subtitle' ? '#04090e' : '#071118', backgroundOpacity: card.type === 'subtitle' ? .88 : .94, borderRadius: card.type === 'subtitle' ? 16 : 28, textColor: card.type === 'metric' ? card.color : '#edf5f7', ...card.style });
  const ownKeys = (value, keys, name, optional = []) => {
    if (!value || typeof value !== 'object' || Array.isArray(value) || Object.keys(value).some(k => !keys.includes(k) && !optional.includes(k)) || keys.some(k => !Object.hasOwn(value, k))) throw new Error(name + '字段不完整或含有未知字段。');
  };
  const number = (value, min, max, name) => {
    if (typeof value !== 'number' || !Number.isFinite(value) || value < min || value > max) throw new Error(name + '必须在 ' + min + ' 到 ' + max + ' 之间。');
    return value;
  };
  const string = (value, max, name) => {
    if (typeof value !== 'string' || value.length > max || /[\u0000-\u0008\u000B\u000C\u000E-\u001F]/.test(value)) throw new Error(name + '文本无效或超过 ' + max + ' 个字符。');
    return value;
  };
  function validateProject(input) {
    ownKeys(input, ['version', 'title', 'aspect', 'duration', 'cards'], '项目', ['watermark', 'exportSettings']);
    if (input.version !== 1) throw new Error('只支持 version: 1 的工作台项目。');
    string(input.title, 120, '项目名称');
    if (!['16:9', '9:16'].includes(input.aspect)) throw new Error('画幅必须是 16:9 或 9:16。');
    number(input.duration, 0.1, LIMITS.duration, '项目时长');
    if (!Array.isArray(input.cards) || input.cards.length > LIMITS.cards) throw new Error('最多允许 200 张卡片。');
    const ids = new Set();
    const cards = input.cards.map(c => {
      ownKeys(c, ['id', 'type', 'text', 'detail', 'start', 'end', 'x', 'y', 'scale', 'color', 'animation'], '卡片', ['style']);
      if (typeof c.id !== 'string' || !/^[a-zA-Z0-9_-]{1,64}$/.test(c.id) || ids.has(c.id)) throw new Error('卡片 ID 无效或重复。');
      ids.add(c.id);
      if (typeof c.type !== 'string' || typeof c.animation !== 'string' || !Object.hasOwn(TYPES, c.type) || !Object.hasOwn(ANIMATIONS, c.animation)) throw new Error('未知卡片样式或动画。');
      string(c.text, LIMITS.text, '卡片'); string(c.detail, 160, '说明');
      number(c.start, 0, input.duration, '入点'); number(c.end, 0, input.duration, '出点');
      if (c.end - c.start < 0.05 - 1e-9) throw new Error('每张卡片至少持续 0.05 秒，出点必须晚于入点。');
      number(c.x, 0, 100, '水平位置'); number(c.y, 0, 100, '垂直位置'); number(c.scale, 0.4, 1.6, '缩放');
      if (!hexColor(c.color)) throw new Error('强调色必须为六位十六进制颜色。');
      if (Object.hasOwn(c, 'style')) {
        ownKeys(c.style, ['backgroundColor', 'backgroundOpacity', 'borderRadius', 'textColor'], '卡片外观');
        if (!hexColor(c.style.backgroundColor) || !hexColor(c.style.textColor)) throw new Error('背景和文字色必须为六位十六进制颜色。');
        number(c.style.backgroundOpacity, 0, 1, '背景不透明度'); number(c.style.borderRadius, 0, 80, '背景圆角');
      }
      return { ...c, ...(c.style ? { style: { ...c.style } } : {}) };
    });
    let watermark = { enabled: false, text: 'FORMWEFT' };
    if (Object.hasOwn(input, 'watermark')) {
      ownKeys(input.watermark, ['enabled', 'text'], '水印');
      if (typeof input.watermark.enabled !== 'boolean') throw new Error('水印开关必须是布尔值。');
      string(input.watermark.text, 80, '水印');
      if (/[\u0000-\u001F\u007F-\u009F\u2028-\u202E\u2066-\u2069]/.test(input.watermark.text)) throw new Error('水印必须是单行可见文本。');
      if (input.watermark.enabled && !input.watermark.text.trim()) throw new Error('开启水印时请填写文字。');
      watermark = { enabled: input.watermark.enabled, text: input.watermark.text };
    }
    let exportSettings = { start: 0, end: Math.min(3, input.duration), fps: 24, includeAudio: true };
    if (Object.hasOwn(input, 'exportSettings')) {
      ownKeys(input.exportSettings, ['start', 'end', 'fps', 'includeAudio'], '导出设置');
      const { start, end, fps, includeAudio } = input.exportSettings;
      number(start, 0, input.duration, '导出入点'); number(end, 0, input.duration, '导出出点');
      if (end <= start) throw new Error('导出出点必须晚于入点。');
      if (![12, 24, 30].includes(fps)) throw new Error('导出帧率必须为 12、24 或 30。');
      if (typeof includeAudio !== 'boolean') throw new Error('原声开关必须是布尔值。');
      exportSettings = { start, end, fps, includeAudio };
    }
    return { version: 1, title: input.title, aspect: input.aspect, duration: input.duration, cards, watermark, exportSettings };
  }
  function parseProject(text) {
    if (typeof text !== 'string' || new TextEncoder().encode(text).length > LIMITS.jsonBytes) throw new Error('项目 JSON 不能超过 1 MiB。');
    let parsed;
    try { parsed = JSON.parse(text); } catch (_) { throw new Error('JSON 格式有误，请导入工作台导出的项目文件。'); }
    return validateProject(parsed);
  }
  function timestamp(value) {
    const m = /^(\d{2}):([0-5]\d):([0-5]\d)[,.](\d{3})$/.exec(value.trim());
    if (!m) throw new Error('SRT 时间格式应为 00:00:01,000。');
    return Number(m[1]) * 3600 + Number(m[2]) * 60 + Number(m[3]) + Number(m[4]) / 1000;
  }
  function parseSrt(text) {
    if (typeof text !== 'string' || new TextEncoder().encode(text).length > LIMITS.jsonBytes) throw new Error('SRT 不能超过 1 MiB。');
    const clean = text.replace(/^\uFEFF/, '').replace(/\r\n?/g, '\n').trim();
    if (!clean) throw new Error('SRT 文件没有字幕。');
    const blocks = clean.split(/\n[ \t]*\n/);
    if (blocks.length > LIMITS.cards) throw new Error('SRT 最多支持 200 段，请先分段。');
    let previous = -1;
    return blocks.map((block, index) => {
      const lines = block.split('\n');
      if (/^\d+$/.test(lines[0].trim())) lines.shift();
      const parts = (lines.shift() || '').split(/\s+-->\s+/);
      if (parts.length !== 2) throw new Error('第 ' + (index + 1) + ' 段缺少有效的时间行。');
      const start = timestamp(parts[0]), end = timestamp(parts[1]);
      if (start < previous) throw new Error('SRT 时间必须按入点升序排列。');
      if (end - start < 0.05 - 1e-9 || end > LIMITS.duration) throw new Error('第 ' + (index + 1) + ' 段时间越界或出点早于入点；最长 1 小时。');
      previous = start;
      const content = lines.join('\n').trim();
      if (!content) throw new Error('第 ' + (index + 1) + ' 段字幕为空。');
      string(content, LIMITS.text, '字幕');
      return { start, end, text: content };
    });
  }
  function newCard(type, id, start, end) {
    const content = { title: ['先给出一个清晰的观点', '让观众知道这段内容为什么值得看'], subtitle: ['把每一句话，讲得更清楚。', ''], keypoint: ['每张卡片只说一件事', '重点提示'], metric: ['3 个步骤', '从口播到清晰的视觉表达'], quote: ['好的视觉，为观点留出空间。', '在这里填写引用来源'], steps: ['先梳理观点\n再安排节奏\n最后检查画面', '把复杂的事情拆开'] };
    if (!Object.hasOwn(content, type)) throw new Error('未知卡片类型。');
    return { id, type, text: content[type][0], detail: content[type][1], start, end, x: 50, y: type === 'subtitle' ? 83 : 50, scale: 1, color: '#7de7eb', animation: type === 'metric' ? 'pop' : 'rise' };
  }
  function sample() {
    const cards = Object.keys(TYPES).map((type, i) => newCard(type, 'sample_' + (i + 1), i * 3, (i + 1) * 3));
    cards[0].text = '把观点，变成画面'; cards[0].detail = '先说清楚，再让画面帮助表达';
    return { version: 1, title: '我的第一段口播动效', aspect: '16:9', duration: 18, cards, watermark: { enabled: false, text: 'FORMWEFT' }, exportSettings: { start: 0, end: 3, fps: 24, includeAudio: true } };
  }
  const clone = p => JSON.parse(JSON.stringify(p));
  function history(initial, limit = 60) {
    let states = [clone(initial)], index = 0;
    return {
      push(value) { const next = clone(value); if (JSON.stringify(next) === JSON.stringify(states[index])) return; states = states.slice(0, index + 1); states.push(next); if (states.length > limit) states.shift(); index = states.length - 1; },
      undo() { if (index) index--; return clone(states[index]); },
      redo() { if (index < states.length - 1) index++; return clone(states[index]); },
      get canUndo() { return index > 0; }, get canRedo() { return index < states.length - 1; }
    };
  }
  function frameTimes(start, end, fps, duration) {
    number(start, 0, duration, '导出入点'); number(end, 0, duration, '导出出点');
    if (![12, 24, 30].includes(fps)) throw new Error('帧率必须为 12、24 或 30。');
    if (end <= start) throw new Error('导出出点必须晚于入点。');
    const count = Math.ceil((end - start) * fps - 1e-8);
    if (count > LIMITS.frames) throw new Error('一次最多 240 帧；请缩短范围或降低帧率。');
    return Array.from({ length: count }, (_, i) => start + i / fps);
  }
  const dimensions = aspect => aspect === '9:16' ? [1080, 1920] : [1920, 1080];
  function canvasPoint(clientX, clientY, rect, width, height) {
    if (![clientX, clientY, rect.left, rect.top, rect.width, rect.height, width, height].every(Number.isFinite) || rect.width <= 0 || rect.height <= 0 || width <= 0 || height <= 0) throw new Error('画布尺寸无效。');
    return { x: (clientX - rect.left) * width / rect.width, y: (clientY - rect.top) * height / rect.height };
  }
  function hitTest(bounds, point) {
    for (let i = bounds.length - 1; i >= 0; i--) {
      const b = bounds[i];
      if (point.x >= b.x && point.x <= b.x + b.width && point.y >= b.y && point.y <= b.y + b.height) return b;
    }
    return null;
  }
  function moveCardPosition(bounds, delta, width, height) {
    const w = bounds.baseWidth ?? bounds.width, h = bounds.baseHeight ?? bounds.height;
    const x = (bounds.baseX ?? bounds.x) + w / 2 + delta.x, y = (bounds.baseY ?? bounds.y) + h / 2 + delta.y;
    if (![w, h, x, y, width, height].every(Number.isFinite) || width <= 0 || height <= 0) throw new Error('拖动位置无效。');
    const clamp = (v, size, frame) => Math.max(20 + size / 2, Math.min(frame - 20 - size / 2, v));
    return { x: clamp(x, w, width) / width * 100, y: clamp(y, h, height) / height * 100 };
  }
  const ease = t => 1 - Math.pow(1 - Math.max(0, Math.min(1, t)), 3);
  function motion(card, time, reduced) {
    if (time < card.start || time >= card.end) return { alpha: 0, dy: 0, scale: 1 };
    if (reduced) return { alpha: 1, dy: 0, scale: 1 };
    const ramp = Math.min(0.38, (card.end - card.start) / 3), incoming = ease((time - card.start) / ramp), outgoing = ease((card.end - time) / ramp);
    return { alpha: Math.min(incoming, outgoing), dy: card.animation === 'rise' ? 32 * (1 - incoming) : 0, scale: card.animation === 'pop' ? 0.88 + 0.12 * incoming : 1 };
  }
  function wrapped(ctx, text, width) {
    const result = [];
    for (const paragraph of text.split('\n')) {
      let line = '';
      for (const char of paragraph) { if (line && ctx.measureText(line + char).width > width) { result.push(line); line = char; } else line += char; }
      result.push(line);
    }
    return result;
  }
  function fitText(ctx, text, width, maxHeight, desired, weight) {
    let size = desired, lines;
    do { ctx.font = weight + ' ' + size + 'px "Segoe UI", "Microsoft YaHei", sans-serif'; lines = wrapped(ctx, text, width); if (lines.length * size * 1.36 <= maxHeight || size <= 17) break; size -= 2; } while (true);
    const maxLines = Math.max(1, Math.floor(maxHeight / (size * 1.36)));
    if (lines.length > maxLines) {
      lines = lines.slice(0, maxLines);
      let last = lines[maxLines - 1]; while (last && ctx.measureText(last + '…').width > width) last = last.slice(0, -1);
      lines[maxLines - 1] = last + '…';
    }
    return { lines, size, lineHeight: size * 1.36 };
  }
  function roundRect(ctx, x, y, w, h, r) {
    r = Math.max(0, Math.min(r, w / 2, h / 2));
    ctx.beginPath(); ctx.moveTo(x + r, y); ctx.arcTo(x + w, y, x + w, y + h, r); ctx.arcTo(x + w, y + h, x, y + h, r); ctx.arcTo(x, y + h, x, y, r); ctx.arcTo(x, y, x + w, y, r); ctx.closePath();
  }
  function inkBlock(ctx, fitted, weight) {
    ctx.font = weight + ' ' + fitted.size + 'px "Segoe UI", "Microsoft YaHei", sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    const rows = fitted.lines.map((text, i) => {
      const m = ctx.measureText(text), visibleAdvance = ctx.measureText(text.trimEnd()).width;
      // Some font fallback engines report only one run's ink bounds for mixed
      // CJK/Latin text. Implausibly short bounds fall back to measured advance.
      const horizontal = Number.isFinite(m.actualBoundingBoxLeft) && Number.isFinite(m.actualBoundingBoxRight) && m.actualBoundingBoxLeft + m.actualBoundingBoxRight > 0 && m.actualBoundingBoxRight >= visibleAdvance - fitted.size * 1.1;
      const vertical = Number.isFinite(m.actualBoundingBoxAscent) && Number.isFinite(m.actualBoundingBoxDescent) && m.actualBoundingBoxAscent + m.actualBoundingBoxDescent > 0;
      return { text, baseline: i * fitted.lineHeight, left: horizontal ? m.actualBoundingBoxLeft : 0, right: horizontal ? m.actualBoundingBoxRight : visibleAdvance,
        ascent: vertical ? m.actualBoundingBoxAscent : fitted.size * .8, descent: vertical ? m.actualBoundingBoxDescent : fitted.size * .2 };
    });
    const top = Math.min(...rows.map(row => row.baseline - row.ascent)), bottom = Math.max(...rows.map(row => row.baseline + row.descent));
    return { rows, top, height: bottom - top };
  }
  function render(ctx, project, time, options = {}) {
    const [width, height] = dimensions(project.aspect);
    ctx.clearRect(0, 0, width, height);
    const bounds = [];
    for (const c of project.cards) {
      const m = motion(c, time, options.reducedMotion);
      if (m.alpha <= 0) continue;
      ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
      const style = cardStyle(c);
      const desired = (c.type === 'metric' ? 100 : c.type === 'title' ? 74 : c.type === 'subtitle' ? 46 : 53) * c.scale;
      let w = Math.min(width * 0.9, (c.type === 'subtitle' ? 1480 : 1120) * c.scale), pad = Math.min(56, w * 0.07);
      if (c.type === 'subtitle') {
        pad = Math.max(12, Math.min(40, 24 * c.scale));
        ctx.font = '500 ' + desired + 'px "Segoe UI", "Microsoft YaHei", sans-serif';
        let natural = Math.max(...c.text.split('\n').map(line => ctx.measureText(line).width));
        if (c.detail) {
          ctx.font = '400 ' + Math.min(27 * c.scale, 32) + 'px "Segoe UI", "Microsoft YaHei", sans-serif';
          natural = Math.max(natural, ...c.detail.split('\n').map(line => ctx.measureText(line).width));
        }
        w = Math.min(w, Math.max(140, Math.ceil(natural + pad * 2)));
      }
      const inner = w - pad * 2;
      const lines = fitText(ctx, c.text, inner - (c.type === 'steps' ? 65 : 0), height * 0.56, desired, c.type === 'subtitle' ? '500' : '650');
      const detail = c.detail ? fitText(ctx, c.detail, inner, 82, Math.min(27 * c.scale, 32), '400') : null;
      const detailH = detail ? detail.lines.length * detail.lineHeight + 24 : 0;
      const top = c.type === 'keypoint' || c.type === 'quote' ? 52 : 0;
      const mainInk = c.type === 'subtitle' ? inkBlock(ctx, lines, '500') : null, detailInk = mainInk && detail ? inkBlock(ctx, detail, '400') : null;
      const gap = detailInk ? Math.min(24, 16 * c.scale) : 0;
      const inkHeight = mainInk ? mainInk.height + gap + (detailInk?.height || 0) : 0;
      const h = Math.min(height * 0.82, pad * 2 + (mainInk ? inkHeight : top + lines.lines.length * lines.lineHeight + detailH));
      const x = Math.max(20, Math.min(width - w - 20, width * c.x / 100 - w / 2));
      const y = Math.max(20, Math.min(height - h - 20, height * c.y / 100 - h / 2));
      // Constrain entry motion too; the returned baseY compensates for this
      // clipped offset so a drag still follows the finger at the bottom edge.
      const dy = Math.min(m.dy, height - h - 20 - y);
      ctx.save(); ctx.globalAlpha = m.alpha; ctx.translate(x + w / 2, y + h / 2 + dy); ctx.scale(m.scale, m.scale); ctx.translate(-w / 2, -h / 2);
      if (style.backgroundOpacity > 0) {
        const rgb = [1, 3, 5].map(index => parseInt(style.backgroundColor.slice(index, index + 2), 16));
        roundRect(ctx, 0, 0, w, h, style.borderRadius); ctx.fillStyle = 'rgba(' + rgb.join(',') + ',' + style.backgroundOpacity + ')'; ctx.fill();
        ctx.strokeStyle = 'rgba(220,242,246,' + Math.min(.2, style.backgroundOpacity * .2 / (c.type === 'subtitle' ? .88 : .94)) + ')'; ctx.lineWidth = 2; ctx.stroke();
      }
      ctx.save(); roundRect(ctx, 0, 0, w, h, c.style ? style.borderRadius : 22); ctx.clip();
      if (c.type === 'title' || c.type === 'metric') { ctx.fillStyle = c.color; ctx.fillRect(pad, 0, Math.min(180, inner), 6); }
      if (c.type === 'quote') { ctx.fillStyle = c.color; ctx.fillRect(0, 0, 7, h); ctx.font = '700 70px Georgia, serif'; ctx.fillText('“', pad, pad + 32); }
      if (c.type === 'keypoint') { ctx.fillStyle = c.color; ctx.font = '600 23px "Segoe UI", sans-serif'; ctx.fillText('KEY POINT', pad, pad + 21); }
      ctx.font = (c.type === 'subtitle' ? '500 ' : '650 ') + lines.size + 'px "Segoe UI", "Microsoft YaHei", sans-serif'; ctx.textBaseline = mainInk ? 'alphabetic' : 'top'; ctx.fillStyle = style.textColor;
      const stepNumbers = c.type === 'steps' ? c.text.split('\n').flatMap((line, i) => wrapped(ctx, line, inner - 65).map((_, j) => j === 0 ? String(i + 1).padStart(2, '0') : '')) : null;
      lines.lines.forEach((line, i) => {
        const yy = pad + top + i * lines.lineHeight;
        if (c.type === 'steps') { ctx.fillStyle = c.color; ctx.fillText(stepNumbers[i] || '', pad, yy); ctx.fillStyle = style.textColor; ctx.fillText(line, pad + 65, yy); }
        else if (mainInk) { const row = mainInk.rows[i]; ctx.fillText(line, w / 2 + (row.left - row.right) / 2, (h - inkHeight) / 2 - mainInk.top + row.baseline); }
        else ctx.fillText(line, pad, yy);
      });
      if (detail) {
        ctx.textAlign = 'left'; ctx.font = '400 ' + detail.size + 'px "Segoe UI", "Microsoft YaHei", sans-serif'; ctx.fillStyle = c.style ? style.textColor : '#b5c7cf';
        detail.lines.forEach((line, i) => {
          if (detailInk) { const row = detailInk.rows[i]; ctx.fillText(line, w / 2 + (row.left - row.right) / 2, (h - inkHeight) / 2 + mainInk.height + gap - detailInk.top + row.baseline); }
          else ctx.fillText(line, pad, pad + top + lines.lines.length * lines.lineHeight + 24 + i * detail.lineHeight);
        });
      }
      ctx.restore(); ctx.restore(); bounds.push({ id: c.id, x: x + w * (1 - m.scale) / 2, y: y + dy + h * (1 - m.scale) / 2, width: w * m.scale, height: h * m.scale, baseX: x, baseY: y + dy - m.dy, baseWidth: w, baseHeight: h });
    }
    if (project.watermark?.enabled === true) {
      ctx.save(); ctx.globalAlpha = .72; ctx.font = '500 26px "Segoe UI", "Microsoft YaHei", sans-serif';
      ctx.textAlign = 'right'; ctx.textBaseline = 'bottom'; ctx.fillStyle = '#edf5f7';
      ctx.shadowColor = 'rgba(0,0,0,.75)'; ctx.shadowBlur = 4;
      ctx.fillText(project.watermark.text, width - 32, height - 32, width * .45);
      ctx.restore();
    }
    return bounds;
  }
  const crcTable = Array.from({ length: 256 }, (_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ c >>> 1 : c >>> 1; return c >>> 0; });
  function crc32(data) { let c = 0xffffffff; for (const byte of data) c = crcTable[(c ^ byte) & 255] ^ c >>> 8; return (c ^ 0xffffffff) >>> 0; }
  function storedZip(entries, maxBytes = LIMITS.zipBytes) {
    if (!Array.isArray(entries) || entries.length > 1000) throw new Error('ZIP 文件数量无效。');
    const parts = [], central = [], encoder = new TextEncoder(); let offset = 0;
    const names = new Set();
    for (const entry of entries) {
      if (typeof entry.name !== 'string' || !/^[a-zA-Z0-9_./-]{1,200}$/.test(entry.name) || entry.name.startsWith('/') || entry.name.split('/').some(p => !p || p === '..' || p === '.') || names.has(entry.name) || !(entry.data instanceof Uint8Array)) throw new Error('ZIP 条目无效。');
      names.add(entry.name); const name = encoder.encode(entry.name), size = entry.data.length, crc = crc32(entry.data);
      if (offset + size + name.length + 30 > maxBytes) throw new Error('导出超过 256 MiB，请缩短时间范围。');
      const local = new Uint8Array(30 + name.length), lv = new DataView(local.buffer);
      lv.setUint32(0, 0x04034b50, true); lv.setUint16(4, 20, true); lv.setUint16(12, 33, true); lv.setUint32(14, crc, true); lv.setUint32(18, size, true); lv.setUint32(22, size, true); lv.setUint16(26, name.length, true); local.set(name, 30);
      const dir = new Uint8Array(46 + name.length), dv = new DataView(dir.buffer);
      dv.setUint32(0, 0x02014b50, true); dv.setUint16(4, 20, true); dv.setUint16(6, 20, true); dv.setUint16(14, 33, true); dv.setUint32(16, crc, true); dv.setUint32(20, size, true); dv.setUint32(24, size, true); dv.setUint16(28, name.length, true); dv.setUint32(42, offset, true); dir.set(name, 46);
      parts.push(local, entry.data); central.push(dir); offset += local.length + size;
    }
    const centralSize = central.reduce((n, p) => n + p.length, 0), end = new Uint8Array(22), ev = new DataView(end.buffer);
    if (offset + centralSize + 22 > maxBytes) throw new Error('导出超过 256 MiB，请缩短时间范围。');
    ev.setUint32(0, 0x06054b50, true); ev.setUint16(8, entries.length, true); ev.setUint16(10, entries.length, true); ev.setUint32(12, centralSize, true); ev.setUint32(16, offset, true);
    return { parts: [...parts, ...central, end], size: offset + centralSize + 22 };
  }
  root.MotionWorkbench = Object.freeze({ LIMITS, TYPES, ANIMATIONS, cardStyle, validateProject, parseProject, parseSrt, newCard, sample, clone, history, frameTimes, dimensions, canvasPoint, hitTest, moveCardPosition, motion, render, crc32, storedZip });
  if (typeof module !== 'undefined' && module.exports) module.exports = root.MotionWorkbench;
})(typeof globalThis !== 'undefined' ? globalThis : window);
